import AriaCore as Aria
import time
def main():
    Aria.start_up()
    Aria.sayHi('')
    Aria.Aria()



if __name__=='__main__':
    main()

time.sleep(3)
