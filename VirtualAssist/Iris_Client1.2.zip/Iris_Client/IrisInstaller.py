import os
def install():
    module='playsound'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='threading'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='wikipedia'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='wolfram-alpha'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='portaudio'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='pytesseract'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='wheel'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='datetime'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='PyAudio'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='speechrecognition'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='Pillow'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='webrowser'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='subproccess'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='json'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='ecapture'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='requests'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='win32api'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='pynput'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='pyjokes'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    module='ctypes'
    try:
        os.system('pip install '+module)
    except:
        print('Error installing '+module+'. Please try manually')
    print('Installation complete.')
