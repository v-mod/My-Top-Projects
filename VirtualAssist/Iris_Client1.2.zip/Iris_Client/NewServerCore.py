import AriaCoreTools
Aria=AriaCoreTools.Aria
AriaAI=AriaCoreTools.AriaAI
Thread=AriaCoreTools.threading.Thread
if __name__=='__main__':
    Aria.start_up()
    Aria.sayHi('Vivaan')
    AriaListen = Thread(target=Aria.Aria)
    AriaListen.start()