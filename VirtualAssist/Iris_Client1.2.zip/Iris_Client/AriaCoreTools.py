import AriaAI
import AriaCore
import main
import threading
Aria=AriaCore
AriaAI=AriaAI
Core=main
threading=threading